import React from "react";

function Info() {
  return(
    <div class="note">
    Javascript and React.js   
      This was an amazing bootcamp taken up by Shaurya Sinha
      We covered everything from Scratch including Javascript React.js,HTML.
    </div>
  );
}

export default Info;